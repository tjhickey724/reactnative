import axios from 'axios';
import { useState } from 'react';
import { Button, ScrollView, Text, TextInput, View } from 'react-native';

const API_BASE_URL = 'https://key-value-store-app.onrender.com/api';  // ← Change this to your actual server IP or localhost for emulator

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [key, setKey] = useState('');
  const [value, setValue] = useState('');
  const [retrievedValue, setRetrievedValue] = useState('');
  const [message, setMessage] = useState('');
  const [debugging, setDebugging] = useState(true);

  const register = async () => {
    try {
      const res = await axios.post(`${API_BASE_URL}/register`, { email, password });
      setMessage(res.data.message);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Registration failed');
    }
  };

  const login = async () => {
    try {
      const res = await axios.post(`${API_BASE_URL}/login`, { email, password }, { withCredentials: true });
      setMessage(res.data.message);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Login failed');
    }
  };

  const storeKeyValue = async () => {
    try {
      const res = await axios.post(`${API_BASE_URL}/store`, { key, value }, { withCredentials: true });
      setMessage(res.data.message);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Store failed');
    }
  };

  const retrieveKeyValue = async () => {
    try {
      const res = await axios.get(`${API_BASE_URL}/retrieve/${key}`, { withCredentials: true });
      setRetrievedValue(res.data.value);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Retrieve failed');
    }
  };

  return (
    <ScrollView style={{ padding: 20, marginTop: 50 }}>
      <Text>Email:</Text>
      <TextInput value={email} onChangeText={setEmail} style={{ borderWidth: 1, marginBottom: 10, padding: 5 }} />

      <Text>Password:</Text>
      <TextInput value={password} onChangeText={setPassword} secureTextEntry style={{ borderWidth: 1, marginBottom: 10, padding: 5 }} />

      <Button title="Register" onPress={register} />
      <Button title="Login" onPress={login} />

      <Text style={{ marginTop: 20 }}>Key:</Text>
      <TextInput value={key} onChangeText={setKey} style={{ borderWidth: 1, marginBottom: 10, padding: 5 }} />

      <Text>Value:</Text>
      <TextInput value={value} onChangeText={setValue} style={{ borderWidth: 1, marginBottom: 10, padding: 5 }} />

      <Button title="Store Key-Value" onPress={storeKeyValue} />
      <Button title="Retrieve Value" onPress={retrieveKeyValue} />

      {retrievedValue ? (
        <Text style={{ marginTop: 10 }}>Retrieved Value: {retrievedValue}</Text>
      ) : null}

      {debugging ? (
        <View>
          <Text style={{ marginTop: 20, color: 'red' }}>Debugging Mode Enabled</Text>
          <Text>API Base URL: {API_BASE_URL}</Text>
          <Text>email: {email}</Text>
          <Text>password: {password}</Text>
          <Text>key: {key}</Text>
          <Text>retrievedValue: {retrievedValue}</Text>   
          <Text>value: {value}</Text>  
          <Text>message: {message}</Text>  

        </View>
        ): 
         null
      }
      <Text style={{ marginTop: 20, color: 'blue' }}>{message}</Text>
    </ScrollView>
  );
}
